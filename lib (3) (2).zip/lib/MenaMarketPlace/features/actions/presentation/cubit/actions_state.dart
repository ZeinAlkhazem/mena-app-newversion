part of 'actions_cubit.dart';

abstract class ActionsState extends Equatable {
  const ActionsState();

  @override
  List<Object> get props => [];
}

class ActionsInitial extends ActionsState {}
