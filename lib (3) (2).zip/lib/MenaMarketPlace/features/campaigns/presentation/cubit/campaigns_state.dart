part of 'campaigns_cubit.dart';

abstract class CampaignsState extends Equatable {
  const CampaignsState();

  @override
  List<Object> get props => [];
}

class CampaignsInitial extends CampaignsState {}
