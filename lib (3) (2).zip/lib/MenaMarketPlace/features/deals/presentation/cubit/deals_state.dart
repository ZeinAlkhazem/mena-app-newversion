part of 'deals_cubit.dart';

abstract class DealsState extends Equatable {
  const DealsState();

  @override
  List<Object> get props => [];
}

class DealsInitial extends DealsState {}
