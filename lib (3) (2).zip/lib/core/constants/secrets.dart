class YourSecret {
  static const int appID = 604854274;

  static const String appSign = 'b61ab3cfc945e5b46bcd65187fa7bac30f34621e4756c143a1dcabdda2764f76';
}