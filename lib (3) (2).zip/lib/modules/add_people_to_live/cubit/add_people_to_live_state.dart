part of 'add_people_to_live_cubit.dart';

@immutable
abstract class AddPeopleToLiveState {}

class AddPeopleToLiveInitial extends AddPeopleToLiveState {}
