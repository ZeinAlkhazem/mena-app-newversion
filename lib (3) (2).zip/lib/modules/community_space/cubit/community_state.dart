part of 'community_cubit.dart';

@immutable
abstract class CommunityState {}

class CommunityInitial extends CommunityState {}
class CurrentViewChanged extends CommunityState {}
