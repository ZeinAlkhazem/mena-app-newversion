part of 'promotions_cubit.dart';

@immutable
abstract class PromotionsState {}

class PromotionsInitial extends PromotionsState {}

class CurrentViewChanged extends PromotionsState {}
