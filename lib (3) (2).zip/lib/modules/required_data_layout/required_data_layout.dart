import 'package:flutter/material.dart';


class RequiredDataLayout extends StatelessWidget {
  const RequiredDataLayout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
