
abstract class ToolsState {}

class ToolsInitial extends ToolsState {}
class GettingEServicesState extends ToolsState {}
class SuccessGettingEServicesState extends ToolsState {}
class ErrorGettingEServicesState extends ToolsState {}
